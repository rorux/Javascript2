

const products = [
    { id: 1, title: 'Invicta IN9204OB', price: 9000, picture: '1.jpg' },
    { id: 2, title: 'Casio G-SHOCK GMW-B5000D-1E', price: 49000, picture: '2.jpg' },
    { id: 3, title: 'Boccia Titanium 3608-02', price: 5000, picture: '3.jpg' },
    { id: 4, title: 'Casio G-SHOCK GST-B200D-1AER', price: 34000, picture: '4.jpg' },
    { id: 5, title: 'Ingersoll I07401', price: 19000, picture: '5.jpg' },
    { id: 6, title: 'Traser TR_109040', price: 25000, picture: '6.jpg' },
    { id: 7, title: 'Orient ER27004W', price: 10000, picture: '7.jpg' },
    { id: 8, title: 'Штурманские 2609-3714129', price: 29000, picture: '8.jpg' },
    { id: 9, title: 'Aviator V.1.22.0.149.4', price: 27000, picture: '9.jpg' }
];


const renderProduct = (title = 'Часы', price = 1000, picture) => `<div class="product-item">
                                                                        <img class="product-item-picture" height="300" src="img/${picture}">
                                                                        <h3 class="product-item-title">${title}</h3>
                                                                        <p class="product-item-price">${price} руб.</p>
                                                                        <button class="product-item-buy">в корзину</button>
                                                                    </div>`;

const render = productsList => {
    const productsElements = productsList.map(item => renderProduct(item.title, item.price, item.picture));
    productsElements.forEach(item => document.querySelector('.products').innerHTML += item);
};

render(products);